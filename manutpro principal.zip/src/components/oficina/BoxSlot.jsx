import React from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

const statusClasses = {
  aguardando_mao_de_obra: "bg-amber-800/60 border-amber-700 text-amber-100",
  aguardando_peca: "bg-yellow-800/60 border-yellow-700 text-yellow-100",
  em_andamento: "bg-blue-800/60 border-blue-700 text-blue-100",
  preventiva_parcial: "bg-purple-800/60 border-purple-700 text-purple-100",
  concluida: "bg-green-800/60 border-green-700 text-green-100",
};

export default function BoxSlot({ label, equipamento }) {
  const isLivre = !equipamento;
  const cls = isLivre
    ? "bg-slate-700/50 border-dashed border-slate-600 text-slate-300"
    : statusClasses[equipamento.status] || "bg-slate-800/50 border-slate-700 text-slate-100";

  return (
    <Card className={`w-full rounded-xl border h-16 ${cls}`}>
      <CardContent className="p-2 h-16 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 w-full">
          <div className="text-[9px] font-semibold uppercase tracking-wide text-slate-300 w-16 shrink-0">
            {label}
          </div>
          <div className="flex-1 font-bold truncate text-white">
            {isLivre ? 'Livre' : equipamento.codigo}
          </div>
          {!isLivre && equipamento.status && (
            <Badge className="hidden 2xl:inline-flex bg-white/10 text-slate-200 capitalize border border-white/20">
              {equipamento.status.replaceAll('_', ' ')}
            </Badge>
          )}
        </div>
      </CardContent>
    </Card>
  );
}