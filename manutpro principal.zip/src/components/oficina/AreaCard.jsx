import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function AreaCard({ title, equipamentos = [] }) {
  return (
    <Card className="rounded-2xl border-slate-700 bg-slate-800/50 backdrop-blur-sm text-white">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-bold text-white">{title}</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        {equipamentos.length === 0 ? (
          <div className="text-slate-400 text-sm">Sem equipamentos</div>
        ) : (
          <div className="flex flex-wrap gap-2">
            {equipamentos.map((e) => (
              <Badge key={e.id} className="bg-blue-600 text-white text-sm px-3 py-1 rounded-full border-blue-500">
                {e.codigo}
              </Badge>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}