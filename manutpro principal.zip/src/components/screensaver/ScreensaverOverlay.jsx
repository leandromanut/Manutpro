import React from "react";

export default function ScreensaverOverlay({
  imageUrl,
  videoUrl,
  message,
  currentTime,
  turno,
  showClock = true,
  showTurno = true,
  dimBackground = true,
  position = "center",
}) {
  const bg = imageUrl ||
    "https://images.unsplash.com/photo-1518131678677-aad6c1f9ccbd?q=80&w=2070&auto=format&fit=crop";

  const dateStr = currentTime.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });
  const timeStr = currentTime.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

  const posClasses = {
    'top-left': 'items-start justify-start p-6',
    'top-right': 'items-start justify-end p-6',
    'center': 'items-center justify-center p-6',
    'center-top': 'items-start justify-center p-6',
    'center-bottom': 'items-end justify-center p-6',
    'center-left': 'items-center justify-start p-6',
    'center-right': 'items-center justify-end p-6',
    'bottom-left': 'items-end justify-start p-6',
    'bottom-right': 'items-end justify-end p-6',
  };

  const isCenterPosition = ['center','center-top','center-bottom','center-left','center-right'].includes(position);

  return (
    <div className="w-full h-full relative bg-black">
      {videoUrl ? (
        <video
          src={videoUrl}
          className="absolute inset-0 w-full h-full object-contain"
          autoPlay
          muted
          loop
          playsInline
        />
      ) : (
        <img src={bg} alt="fundo" className="absolute inset-0 w-full h-full object-contain" />
      )}
      {dimBackground && (
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/70" />
      )}

      {/* Cabeçalho com relógio/data/turno */}
      {(showClock || (showTurno && turno)) && !isCenterPosition && (
        <div className="absolute top-4 md:top-6 left-1/2 -translate-x-1/2 text-white text-center px-4 pointer-events-none">
          {showClock && (
            <>
              <div className="text-5xl md:text-7xl font-extrabold tracking-tight drop-shadow-lg">{timeStr}</div>
              <div className="text-lg md:text-2xl mt-1 text-white/90">{dateStr}</div>
            </>
          )}
          {showTurno && turno && (
            <div className="mt-2 text-sm md:text-base bg-white/10 border border-white/20 px-3 py-1 rounded-full inline-block">
              TURNO {turno.letra} • {turno.supervisor}
            </div>
          )}
        </div>
      )}

      {/* Mensagem posicionada */}
      {(message || (isCenterPosition && (showClock || (showTurno && turno)))) && (
        <div className={`absolute inset-0 flex ${posClasses[position] || posClasses.center} text-white`}>
          <div className="max-w-4xl">
            {isCenterPosition && (showClock || (showTurno && turno)) && (
              <div className="mb-3 md:mb-4 pointer-events-none">
                {showClock && (
                  <>
                    <div className="text-4xl md:text-6xl font-extrabold tracking-tight drop-shadow-[0_2px_8px_rgba(0,0,0,0.6)]">{timeStr}</div>
                    <div className="text-base md:text-xl mt-0.5 text-white/95 drop-shadow-[0_2px_8px_rgba(0,0,0,0.6)]">{dateStr}</div>
                  </>
                )}
                {showTurno && turno && (
                  <div className="mt-1 text-xs md:text-sm bg-black/35 backdrop-blur px-3 py-1 rounded-full inline-block">
                    TURNO {turno.letra} • {turno.supervisor}
                  </div>
                )}
              </div>
            )}
            {message && (
              <p className="text-2xl md:text-4xl font-bold leading-relaxed drop-shadow-[0_2px_8px_rgba(0,0,0,0.6)]">{message}</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}