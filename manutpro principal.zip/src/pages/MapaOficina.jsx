import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import BoxSlot from "../components/oficina/BoxSlot";
import AreaCard from "../components/oficina/AreaCard";
import { Button } from "@/components/ui/button";
import { Clock, Calendar, Maximize, Minimize } from "lucide-react";

export default function MapaOficina() {
  const [now, setNow] = React.useState(new Date());
  const [isFullscreen, setIsFullscreen] = React.useState(false);
  React.useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => {
        setIsFullscreen(true);
      }).catch((err) => {
        console.error('Erro ao entrar em fullscreen:', err);
      });
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().then(() => {
          setIsFullscreen(false);
        });
      }
    }
  };

  React.useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const { data: equipamentos = [] } = useQuery({
    queryKey: ["equipamentos"],
    queryFn: () => base44.entities.Equipamento.list(),
    initialData: [],
  });

  const todayStr = format(new Date(), "yyyy-MM-dd");
  const { data: turnos = [] } = useQuery({
    queryKey: ["turno", todayStr],
    queryFn: () => base44.entities.Turno.filter({ data: todayStr, ativo: true }, "-created_date", 1),
    initialData: [],
  });
  const turno = turnos?.[0];

  const byLoc = (loc) => equipamentos.find((e) => e.localizacao === loc);
  const groupByLoc = (loc) => equipamentos.filter((e) => e.localizacao === loc);

  const boxes = Array.from({ length: 14 }, (_, i) => i + 1);

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-2 md:p-3 overflow-hidden flex flex-col">
      <div className="max-w-full mx-auto space-y-8">
        {/* Cabeçalho */}
        <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-lg md:rounded-xl shadow-2xl p-2 md:p-2.5 mb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 md:gap-3">
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68e8575a62de43da7b2001a5/a68f4e2b0_image.png"
                alt="Vale Logo"
                className="h-7 md:h-10 bg-white rounded-lg p-1" />
              <div>
                <h1 className="text-sm md:text-xl font-bold text-white mb-0.5">
                  MAPA DA OFICINA - MANUTENÇÃO
                </h1>
                <p className="text-[10px] md:text-xs text-white/90 hidden md:block">
                  Localização em Tempo Real - Onça Puma
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 md:gap-3">
              <div className="text-right">
                <div className="flex items-center gap-1 md:gap-2 justify-end mb-0.5">
                  <Calendar className="w-3 h-3 md:w-3.5 md:h-3.5 text-white" />
                  <p className="text-xs md:text-base font-bold text-white">
                    {now.toLocaleDateString('pt-BR')}
                  </p>
                </div>
                <div className="flex items-center gap-1 md:gap-2 justify-end">
                  <Clock className="w-3 h-3 md:w-3.5 md:h-3.5 text-white" />
                  <p className="text-xs md:text-base font-bold text-white">
                    {now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </p>
                </div>
                {turno &&
                  <div className="mt-1 bg-white/20 backdrop-blur-sm rounded px-1.5 md:px-2 py-0.5">
                    <p className="text-[10px] md:text-xs font-bold text-white">
                      TURNO {turno.letra} - {turno.supervisor}
                    </p>
                    {turno.tecnicos_lideres &&
                      <p className="text-[8px] md:text-[10px] font-semibold text-white/90 hidden md:block">
                        Técnicos: {turno.tecnicos_lideres}
                      </p>
                    }
                  </div>
                }
              </div>
              <Button
                onClick={toggleFullscreen}
                className="bg-white/20 hover:bg-white/30 backdrop-blur-sm border-2 border-white/40 text-white h-8 w-8 md:h-12 md:w-12 p-0"
                title={isFullscreen ? "Sair da Tela Cheia (ESC)" : "Tela Cheia"}>
                {isFullscreen ?
                  <Minimize className="w-4 h-4 md:w-5 md:h-5" /> :
                  <Maximize className="w-4 h-4 md:w-5 md:h-5" />
                }
              </Button>
            </div>
          </div>
        </div>

        {/* Boxes - duas fileiras (Interno em cima, Externo embaixo), Box 1 à esquerda */}
        <section className="bg-slate-800/50 backdrop-blur border border-slate-700 rounded-2xl p-4 shadow-sm">
          <div className="text-xs text-slate-400 font-semibold mb-2">Boxes da oficina</div>
          <div>
            <div className="space-y-2">
              {/* Linha Interno */}
              <div className="grid grid-cols-14 gap-2">
                {boxes.map((n) => (
                  <BoxSlot
                    key={`in-${n}`}
                    label={`Box ${n} Interno`}
                    equipamento={byLoc(`Box ${n} Interno`)}
                  />
                ))}
              </div>
              {/* Linha Externo */}
              <div className="grid grid-cols-14 gap-2">
                {boxes.map((n) => (
                  <BoxSlot
                    key={`ex-${n}`}
                    label={`Box ${n} Externo`}
                    equipamento={byLoc(`Box ${n} Externo`)}
                  />
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Áreas: Manutenção de Pneus (esquerda), Lavador (direita) */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <AreaCard title="Manutenção de Pneus" equipamentos={groupByLoc("Manutenção de Pneus")} />
          </div>
          <div className="md:justify-self-end">
            <AreaCard title="Lavador" equipamentos={groupByLoc("Lavador")} />
          </div>
        </section>

        {/* Pátio central e largo */}
        <section>
          <div className="max-w-3xl mx-auto">
            <AreaCard title="Pátio" equipamentos={groupByLoc("Pátio")} />
          </div>
        </section>
      </div>
    </div>
  );
}