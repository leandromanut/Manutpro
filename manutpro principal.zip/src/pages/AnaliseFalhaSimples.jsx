import React, { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, FileText, Save, Download, Wrench } from "lucide-react";
import jsPDF from "jspdf";

export default function AnaliseFalhaSimples() {
  const [dataSelecionada, setDataSelecionada] = useState(new Date().toISOString().split("T")[0]);
  const [liberacaoSelecionada, setLiberacaoSelecionada] = useState(null);

  const [dadosFalha, setDadosFalha] = useState("");
  const [partNumber, setPartNumber] = useState("");
  const [porques, setPorques] = useState(["", "", "", "", ""]);
  const [motivoFalha, setMotivoFalha] = useState("");
  const [sugestao, setSugestao] = useState("");


  const queryClient = useQueryClient();

  const { data: turnos = [] } = useQuery({
    queryKey: ["turnos"],
    queryFn: () => base44.entities.Turno.list("-created_date"),
    refetchOnWindowFocus: false,
  });
  const turnoAtivo = turnos.find(t => t.ativo);

  const { data: liberacoes = [], isFetching: liberacoesLoading } = useQuery({
    queryKey: ["liberacoes", dataSelecionada, turnoAtivo?.letra],
    queryFn: async () => {
      if (!turnoAtivo?.letra) return [];
      return base44.entities.LiberacaoEquipamento.filter({ data_liberacao: dataSelecionada, turno: turnoAtivo.letra });
    },
    enabled: !!turnoAtivo?.letra,
    refetchOnWindowFocus: false,
  });

  const liberarOpcoes = useMemo(() => {
    // Dedup por TAG
    const seen = new Set();
    const list = [];
    for (const l of liberacoes) {
      const tag = (l.codigo_equipamento || "").trim().toUpperCase();
      if (tag && !seen.has(tag)) {
        seen.add(tag);
        list.push({ id: l.id, tag, nome: l.nome_equipamento || tag, raw: l });
      }
    }
    return list.sort((a,b) => a.tag.localeCompare(b.tag));
  }, [liberacoes]);

  const createRafMutation = useMutation({
    mutationFn: (payload) => base44.entities.AnaliseFalhaSimples.create(payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["rafs", dataSelecionada, turnoAtivo?.letra] });
      alert("RAF salva com sucesso!");
    },
  });

  const { data: rafs = [] } = useQuery({
    queryKey: ["rafs", dataSelecionada, turnoAtivo?.letra],
    queryFn: async () => base44.entities.AnaliseFalhaSimples.filter({ data_turno: dataSelecionada, turno: turnoAtivo?.letra }),
    enabled: !!turnoAtivo?.letra,
    refetchOnWindowFocus: false,
  });

  const handleSalvar = async () => {
    if (!liberacaoSelecionada) {
      alert("Selecione um equipamento liberado.");
      return;
    }
    if (!dadosFalha.trim()) {
      alert("Descreva os dados da falha.");
      return;
    }

    const payload = {
      liberacao_id: liberacaoSelecionada.raw.id,
      equipamento_id: liberacaoSelecionada.raw.equipamento_id || "",
      codigo_equipamento: liberacaoSelecionada.tag,
      data_turno: dataSelecionada,
      turno: turnoAtivo?.letra || "",
      dados_falha: dadosFalha,
      part_number: partNumber,
      porques: porques.filter(Boolean),
      motivo_falha: motivoFalha,
      sugestao_preventiva: sugestao,
    };

    await createRafMutation.mutateAsync(payload);
  };

  const handleExportarPdf = () => {
    const doc = new jsPDF();
    const margin = 14;
    let y = margin;

    doc.setFontSize(16);
    doc.text("Análise de Falha (RAF)", margin, y); y += 8;

    doc.setFontSize(10);
    doc.text(`Data: ${new Date(dataSelecionada+"T00:00:00").toLocaleDateString("pt-BR")}  Turno: ${turnoAtivo?.letra || "-"}` , margin, y); y += 6;
    if (liberacaoSelecionada) {
      doc.text(`Equipamento: ${liberacaoSelecionada.tag} - ${liberacaoSelecionada.nome}`, margin, y); y += 6;
    }

    const addMultiline = (title, text) => {
      if (!text) return;
      doc.setFont(undefined, "bold");
      doc.text(title, margin, y); y += 5;
      doc.setFont(undefined, "normal");
      const lines = doc.splitTextToSize(text, 180);
      lines.forEach(line => { doc.text(line, margin, y); y += 5; if (y > 280) { doc.addPage(); y = margin; } });
      y += 3;
    };

    addMultiline("Dados da Falha:", dadosFalha);
    if (partNumber) { doc.text(`Part Number: ${partNumber}`, margin, y); y += 6; }

    const preenchidos = porques.map((p, i) => ({i, p})).filter(x => x.p);
    if (preenchidos.length) {
      doc.setFont(undefined, "bold");
      doc.text("5 Porquês:", margin, y); y += 5;
      doc.setFont(undefined, "normal");
      preenchidos.forEach(x => { addMultiline(`Por quê ${x.i+1}:`, x.p); });
    }

    addMultiline("Motivo da Falha:", motivoFalha);
    addMultiline("Sugestão para não recorrência:", sugestao);

    doc.save(`RAF_${liberacaoSelecionada?.tag || "sem_equip"}_${dataSelecionada}.pdf`);
  };



  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-2"><Wrench className="w-7 h-7" /> Análise de Falha (RAF)</h1>
            <p className="text-slate-600">Registre 5 Porquês de forma simples e gere ações preventivas.</p>
          </div>
          <div className="flex items-center gap-3">
            <div>
              <Label className="text-xs">Data do turno</Label>
              <Input type="date" value={dataSelecionada} onChange={(e)=>setDataSelecionada(e.target.value)} />
            </div>
            <div className="text-sm text-slate-700">
              <p><strong>Turno:</strong> {turnoAtivo?.letra || "—"}</p>
              <p className="text-xs text-slate-500">{turnoAtivo?.supervisor ? `Supervisor: ${turnoAtivo.supervisor}` : ''}</p>
            </div>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Selecionar Equipamento Liberado</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Equipamento</Label>
                <Select value={liberacaoSelecionada?.id || ""} onValueChange={(v)=>{
                  const item = liberarOpcoes.find(o=>o.id===v);
                  setLiberacaoSelecionada(item || null);
                }}>
                  <SelectTrigger>
                    <SelectValue placeholder={liberacoesLoading ? "Carregando..." : "Escolha um equipamento liberado"} />
                  </SelectTrigger>
                  <SelectContent>
                    {liberarOpcoes.map(op => (
                      <SelectItem key={op.id} value={op.id}>{op.tag} — {op.nome}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {liberacaoSelecionada && (
                <div className="flex items-end gap-2">
                  <Badge className="bg-green-600 text-white">Liberado</Badge>
                  <span className="text-sm text-slate-600">OM: {liberacaoSelecionada.raw.ordem_manutencao || '—'}</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">Registro da RAF</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Dados da Falha *</Label>
              <Textarea value={dadosFalha} onChange={(e)=>setDadosFalha(e.target.value)} placeholder="Descreva o que ocorreu, sintomas, condições operacionais, etc." className="min-h-[90px]" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label>Part Number</Label>
                <Input value={partNumber} onChange={(e)=>setPartNumber(e.target.value)} placeholder="Ex: 9X-1234" />
              </div>
            </div>

            <div className="border rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <p className="font-semibold">5 Porquês</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {porques.map((p, i) => (
                  <div key={i}>
                    <Label>{`Por quê ${i+1}`}</Label>
                    <Textarea value={p} onChange={(e)=>{
                      const arr = [...porques]; arr[i] = e.target.value; setPorques(arr);
                    }} placeholder={`Resposta do por quê ${i+1}`} />
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Motivo da Falha (consolidado)</Label>
                <Textarea value={motivoFalha} onChange={(e)=>setMotivoFalha(e.target.value)} placeholder="Resumo objetivo do motivo da falha" className="min-h-[70px]" />
              </div>
              <div>
                <Label>Sugestão para não recorrência</Label>
                <Textarea value={sugestao} onChange={(e)=>setSugestao(e.target.value)} placeholder="Ações preventivas práticas" className="min-h-[70px]" />
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <Button onClick={handleSalvar} className="bg-blue-600 hover:bg-blue-700">
                <Save className="w-4 h-4 mr-2"/> Salvar RAF
              </Button>
              <Button onClick={handleExportarPdf} variant="outline">
                <Download className="w-4 h-4 mr-2"/> Exportar PDF
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">RAFs deste turno</CardTitle>
          </CardHeader>
          <CardContent>
            {rafs.length === 0 ? (
              <p className="text-sm text-slate-500">Nenhuma RAF registrada para esta data/turno.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {rafs.map((r) => (
                  <div key={r.id} className="border rounded p-3 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-semibold">{r.codigo_equipamento}</p>
                      <Badge variant="outline">{r.part_number || "sem PN"}</Badge>
                    </div>
                    <p className="text-sm line-clamp-2 text-slate-700">{r.dados_falha}</p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}