import React, { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Brain, Calendar, Filter, RefreshCw, AlertTriangle, Lightbulb, MessageSquare, Send, HelpCircle, Sparkles } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ResponsiveContainer, ComposedChart, Bar, Line, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { Tooltip as UiTooltip, TooltipProvider, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip";

function formatISO(d) {
  return new Date(d).toISOString().split("T")[0];
}

export default function AnaliseCorretiva() {
  const hoje = new Date();
  const seteDiasAtras = new Date();
  seteDiasAtras.setDate(hoje.getDate() - 7);

  const [inicio, setInicio] = useState(formatISO(seteDiasAtras));
  const [fim, setFim] = useState(formatISO(hoje));
  const [tag, setTag] = useState("");
  const [frota, setFrota] = useState("todas");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState(null);
  const [promptPreview, setPromptPreview] = useState("");
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [showParetoDialog, setShowParetoDialog] = useState(false);
  const [chatMessages, setChatMessages] = useState([]);
  const [chatInput, setChatInput] = useState("");
  const [isChatting, setIsChatting] = useState(false);
  const [expandedCodes, setExpandedCodes] = useState({});
  const [totalConsideredRecords, setTotalConsideredRecords] = useState(0);

  // Dados
  const { data: equipamentos = [] } = useQuery({
    queryKey: ["equipamentos-analise"],
    queryFn: () => base44.entities.Equipamento.list(),
    initialData: [],
  });
  const { data: liberacoes = [] } = useQuery({
    queryKey: ["liberacoes-analise"],
    queryFn: () => base44.entities.LiberacaoEquipamento.list(),
    initialData: [],
  });
  const { data: planos = [] } = useQuery({
    queryKey: ["planos-analise"],
    queryFn: () => base44.entities.PlanoDeAcao.list("-created_date"),
    initialData: [],
  });

  const period = useMemo(() => ({
    start: new Date(inicio + "T00:00:00"),
    end: new Date(fim + "T23:59:59"),
  }), [inicio, fim]);

  const equipamentosFiltrados = useMemo(() => {
    return equipamentos.filter((e) => {
      if (frota !== "todas" && e.frota !== frota) return false;
      if (tag && !(e.codigo || "").toUpperCase().includes(tag.toUpperCase())) return false;
      // considerar cartões de corretiva criados/iniciados no período
      const di = e.data_inicio ? new Date(e.data_inicio + "T00:00:00") : null;
      const created = e.created_date ? new Date(e.created_date) : null;
      const inPeriodo = di ? (di >= period.start && di <= period.end) : (created ? (created >= period.start && created <= period.end) : true);
      return (e.tipo_manutencao === "corretiva") && inPeriodo;
    });
  }, [equipamentos, period, frota, tag]);

  const dataset = useMemo(() => {
    const byTag = {};
    equipamentosFiltrados.forEach((e) => {
      byTag[e.codigo] = byTag[e.codigo] || {
        codigo: e.codigo,
        tipo: e.tipo,
        frota: e.frota,
        status: e.status,
        tipo_manutencao: e.tipo_manutencao,
        data_inicio: e.data_inicio || null,
        hora_inicio: e.hora_inicio || null,
        descricao_atividade: e.descricao_atividade || "",
        anotacoes: e.anotacoes || "",
        acoes: [],
        liberacoes: [],
      };
    });

    // anexar liberações dentro do período (respeitando TAG quando houver)
    liberacoes.forEach((l) => {
      const data = l.data_liberacao ? new Date(l.data_liberacao + "T00:00:00") : null;
      if (data && data >= period.start && data <= period.end) {
        const key = l.codigo_equipamento || l.nome_equipamento;
        if (!key) return;
        const matchesTag = tag ? key.toUpperCase().includes(tag.toUpperCase()) : true;
        if (!matchesTag) return;
        byTag[key] = byTag[key] || { codigo: key, acoes: [], liberacoes: [] };
        byTag[key].liberacoes.push({
          data_liberacao: l.data_liberacao,
          hora_liberacao: l.hora_liberacao || null,
          tipo_manutencao: l.tipo_manutencao || null,
          atividades_realizadas: l.atividades_realizadas || "",
        });
      }
    });

    // anexar ações (apenas corretiva no período)
    planos.forEach((p) => {
      const aberta = p.data_reuniao ? new Date(p.data_reuniao + "T00:00:00") : null;
      const atual = p.updated_date ? new Date(p.updated_date) : null;
      const inPeriodo = aberta ? (aberta >= period.start && aberta <= period.end) : (atual ? (atual >= period.start && atual <= period.end) : false);
      if (!inPeriodo) return;
      if (tag && p.equipamento_codigo && !p.equipamento_codigo.toUpperCase().includes(tag.toUpperCase())) return;
      const key = p.equipamento_codigo || "SEM_TAG";
      byTag[key] = byTag[key] || { codigo: key, acoes: [], liberacoes: [] };
      byTag[key].acoes.push({
        descricao_acao: p.descricao_acao,
        tipo_acao: p.tipo_acao || null,
        status_acao: p.status_acao,
        numero_om: p.numero_om || null,
        comentarios: p.comentarios || [],
        data_reuniao: p.data_reuniao || null,
        data_conclusao: p.data_conclusao || null,
      });
    });

    return Object.values(byTag);
  }, [equipamentosFiltrados, liberacoes, planos, period, tag]);

  // Recalcula os "Registros considerados" (paradas/ocorrências) com a mesma lógica de filtros (período, frota, TAG inclusivo)
  React.useEffect(() => {
    const tagUpper = (tag || "").toUpperCase();
    const matchesTagIncludes = (val) => !tagUpper || (val || "").toUpperCase().includes(tagUpper);

    // Contar paradas de equipamentos corretivos no período
    const equipamentosCount = (equipamentos || []).filter((e) => {
      if (frota !== "todas" && e.frota !== frota) return false;
      if (!matchesTagIncludes(e.codigo)) return false;
      const di = e.data_inicio ? new Date(e.data_inicio + "T00:00:00") : null;
      const created = e.created_date ? new Date(e.created_date) : null;
      const inPeriodo = di ? (di >= period.start && di <= period.end) : (created ? (created >= period.start && created <= period.end) : false);
      return e.tipo_manutencao === "corretiva" && inPeriodo;
    }).length;

    // Contar liberações no período
    const liberacoesCount = (liberacoes || []).filter((l) => {
      const data = l.data_liberacao ? new Date(l.data_liberacao + "T00:00:00") : null;
      if (!data || data < period.start || data > period.end) return false;
      const key = l.codigo_equipamento || l.nome_equipamento || "";
      if (!matchesTagIncludes(key)) return false;
      return true;
    }).length;

    // Contar planos de ação no período
    const planosCount = (planos || []).filter((p) => {
      const aberta = p.data_reuniao ? new Date(p.data_reuniao + "T00:00:00") : null;
      const atual = p.updated_date ? new Date(p.updated_date) : null;
      const inPeriodo = aberta ? (aberta >= period.start && aberta <= period.end) : (atual ? (atual >= period.start && atual <= period.end) : false);
      if (!inPeriodo) return false;
      if (!matchesTagIncludes(p.equipamento_codigo || "")) return false;
      return true;
    }).length;

    setTotalConsideredRecords(equipamentosCount + liberacoesCount + planosCount);
  }, [equipamentos, liberacoes, planos, period, frota, tag]);

  const handleReset = () => {
    setIsAnalyzing(false);
    setResult(null);
    setPromptPreview("");
    setSelectedCategory(null);
    setShowParetoDialog(false);
  };

  const handleAnalyze = async () => {
    if (dataset.length === 0) {
      alert("Sem dados no período/filtragem selecionados.");
      return;
    }

    setIsAnalyzing(true);
    setResult(null);

    // Compactar dados para o LLM
    const payload = dataset.map((d) => ({
      codigo: d.codigo,
      frota: d.frota,
      inicio: d.data_inicio,
      descricao_atividade: d.descricao_atividade,
      anotacoes: d.anotacoes,
      liberacoes: d.liberacoes,
      acoes: d.acoes.map((a) => ({
        descricao_acao: a.descricao_acao,
        tipo_acao: a.tipo_acao,
        status_acao: a.status_acao,
        numero_om: a.numero_om,
        data_reuniao: a.data_reuniao,
        data_conclusao: a.data_conclusao,
        comentarios: (a.comentarios || []).map((c) => `${c.data} - ${c.autor}: ${c.comentario}`),
      })),
    }));

    const prompt = `Você é uma analista de manutenção de equipamentos móveis, sênior e especialista nos seguintes modelos e fabricantes.
    Modelos por tipo:
    - Caminhão Hidráulico: CAT 740, CAT 740B, VOLVO A45G, KRESS 621G, KRESS 631G, Kress
    - Motoniveladora: CAT 12H, CAT 14
    - Trator de esteira: CAT D6T, CAT D9T
    - Caminhão Rodoviário: P420 Scania Comboio, G450 Scania, PRANCHA P420, P420 Scania 8x4, G540 Scania 8x4, P420 Scania 6x4, P420 Scania 6x4 Pipa
    - Escavadeira Hidráulica: CAT 416E, CAT 320DL, CAT 323DL, CAT 365CL, CAT374, CAT395
    - Perfuratriz Hidráulica: EPIROC ECM660, EPIROC D65
    - Pá Carregadeira: CAT 988H, CAT 938GII, CAT 966H
    Fabricantes: Caterpillar, Volvo, Epiroc, Scania, Kress, Manitou.
    Considere também sistemas e subsistemas: ar-condicionado (HVAC), estrutura, cabine, pneus, FPS (sistema de proteção contra incêndio), freios, direção, suspensão, transmissão e chassi.
    Analise o período ${inicio} a ${fim} usando os dados e produza um diagnóstico acionável.
    Faça:
    1) Classificação de tipos de falha (ex.: vazamento, elétrica, eletrônico, mecânico, complementos) e mapeamento por sistemas (hidráulico, elétrico, pneumático, eletrônico, mecânico) E também pelos sistemas adicionais listados acima.
    2) Calcule, quando possível, o tempo de equipamento parado (de data_inicio até data/hora de liberação) e agregue métricas.
    3) Contagem e repetitividade por equipamento e por categoria.
    4) Pareto profundo das categorias (com percentuais e ACUMULADO) E um detalhamento por SUBCATEGORIAS (ex.: em Elétrico: curto-circuito, aberto, mau contato, sensor, chicote, fusível, etc.). Use "cumulative" como o somatório ACUMULADO do percentual das categorias até aquela posição (ex.: 80 = as N primeiras categorias somam 80%).
    5) Tendências (aumentando/diminuindo) para as categorias relevantes.
    6) SUGESTÕES: traga recomendações TÉCNICAS e de PROCESSO de forma PROFUNDA e FUNCIONAL, no formato 5W2H: título, racional (por que), área/owner, prioridade (alta/média/baixa), impacto esperado em horas evitadas, nível de custo (baixo/médio/alto), passos práticos (checklist).
    7) Em "notes": escreva um relatório narrativo extenso, técnico e didático (mínimo ~300-500 palavras), cobrindo: visão geral do período, principais famílias de falha, relações causa–efeito por sistema, hipóteses mais prováveis, riscos, quick-wins e recomendações prioritárias.
    Responda em português, seguindo exatamente o schema JSON pedido. Dados base (amostra limitada):\n${JSON.stringify(payload).slice(0, 18000)}...`;

    setPromptPreview(prompt);

    const schema = {
      type: "object",
      properties: {
        metrics: {
          type: "object",
          properties: {
            total_failures: { type: "number" },
            unique_equipments: { type: "number" },
            total_downtime_hours: { type: "number" },
            avg_downtime_hours: { type: "number" },
          },
        },
        pareto: {
          type: "array",
          items: { type: "object", properties: { category: { type: "string" }, count: { type: "number" }, percentage: { type: "number" }, cumulative: { type: "number" } } },
        },
        pareto_breakdown: {
          type: "object",
          additionalProperties: {
            type: "array",
            items: { type: "object", properties: { subcategory: { type: "string" }, count: { type: "number" }, percentage: { type: "number" }, cumulative: { type: "number" } } },
          },
        },
        failures_by_system: {
          type: "array",
          items: { type: "object", properties: { system: { type: "string" }, count: { type: "number" } } },
        },
        repeated_failures: {
          type: "array",
          items: { type: "object", properties: { codigo: { type: "string" }, category: { type: "string" }, count: { type: "number" } } },
        },
        trends: {
          type: "array",
          items: { type: "object", properties: { category: { type: "string" }, direction: { type: "string" } } },
        },
        suggestions: {
          type: "object",
          properties: {
            technical: { 
              type: "array", 
              items: { 
                type: "object", 
                properties: { 
                  title: { type: "string" },
                  rationale: { type: "string" },
                  owner_area: { type: "string" },
                  priority: { type: "string" },
                  expected_impact_hours: { type: "number" },
                  cost_level: { type: "string" },
                  steps: { type: "array", items: { type: "string" } },
                } 
              } 
            },
            process: { 
              type: "array", 
              items: { 
                type: "object", 
                properties: { 
                  title: { type: "string" },
                  rationale: { type: "string" },
                  owner_area: { type: "string" },
                  priority: { type: "string" },
                  expected_impact_hours: { type: "number" },
                  cost_level: { type: "string" },
                  steps: { type: "array", items: { type: "string" } },
                }
              }
            },
          },
        },
        notes: { type: "string" },
      },
    };

    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt,
        add_context_from_internet: false,
        response_json_schema: schema,
      });
      setResult(res);
    } catch (e) {
      alert("Falha ao executar a análise de IA: " + (e?.message || ""));
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSendChat = async () => {
    const msg = chatInput.trim();
    if (!msg) return;
    setIsChatting(true);
    const nextMsgs = [...chatMessages, { role: 'user', content: msg }];
    setChatMessages(nextMsgs);

    const history = nextMsgs.map(m => `${m.role === 'user' ? 'Usuário' : 'Assistente'}: ${m.content}`).join('\n');

    const persona = `Você é uma analista de manutenção de equipamentos móveis, especialista em marcas e modelos abaixo.
  Modelos por tipo:
  - Caminhão Hidráulico: CAT 740, CAT 740B, VOLVO A45G, KRESS 621G, KRESS 631G, Kress
  - Motoniveladora: CAT 12H, CAT 14
  - Trator de esteira: CAT D6T, CAT D9T
  - Caminhão Rodoviário: P420 Scania Comboio, G450 Scania, PRANCHA P420, P420 Scania 8x4, G540 Scania 8x4, P420 Scania 6x4, P420 Scania 6x4 Pipa
  - Escavadeira Hidráulica: CAT 416E, CAT 320DL, CAT 323DL, CAT 365CL, CAT374, CAT395
  - Perfuratriz Hidráulica: EPIROC ECM660, EPIROC D65
  - Pá Carregadeira: CAT 988H, CAT 938GII, CAT 966H
  Fabricantes: Caterpillar, Volvo, Epiroc, Scania, Kress, Manitou.
  Responda como especialista de campo, prática, orientada a causa-raiz e 5W2H.`;

    const contexto = `Período: ${inicio} a ${fim}. TAG: ${tag || 'todas'}. Frota: ${frota}.
  Resumo atual: ${result ? JSON.stringify(result).slice(0, 7000) : 'Sem resultado de análise ainda.'}`;

    const prompt = `${persona}\n${contexto}\nHistórico:\n${history}\n\nResponda em português, objetiva e com passos práticos quando fizer sentido.`;

    try {
      const answer = await base44.integrations.Core.InvokeLLM({ prompt });
      const content = typeof answer === 'string' ? answer : JSON.stringify(answer);
      setChatMessages(prev => [...prev, { role: 'assistant', content }]);
    } catch (e) {
      setChatMessages(prev => [...prev, { role: 'assistant', content: 'Falha ao obter resposta da IA: ' + (e?.message || '') }]);
    } finally {
      setIsChatting(false);
      setChatInput("");
    }
  };

  const toggleExpanded = (code) => setExpandedCodes(prev => ({ ...prev, [code]: !prev[code] }));

    return (
    <div className="relative min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-6">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -top-32 -left-32 h-72 w-72 bg-gradient-to-br from-sky-400/30 to-indigo-500/30 blur-3xl rounded-full" />
        <div className="absolute -bottom-24 right-0 h-80 w-80 bg-gradient-to-br from-emerald-400/20 to-cyan-500/20 blur-3xl rounded-full" />
      </div>
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-3xl md:text-4xl font-extrabold flex items-center gap-3">
              <Brain className="w-8 h-8 text-sky-600" />
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-sky-600 via-indigo-600 to-purple-600">Análise Corretiva (IA)</span>
              <Sparkles className="w-5 h-5 text-indigo-500" />
            </h1>
            <p className="text-slate-600">Identificação de padrões, Pareto, tendências e sugestões acionáveis sob demanda.</p>
          </div>
        </div>

        <Card className="no-print">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Filter className="w-5 h-5"/> Filtros</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div>
                <Label>Início</Label>
                <Input type="date" value={inicio} onChange={(e) => setInicio(e.target.value)} />
              </div>
              <div>
                <Label>Fim</Label>
                <Input type="date" value={fim} onChange={(e) => setFim(e.target.value)} />
              </div>
              <div>
                <Label>TAG (opcional)</Label>
                <Input placeholder="Ex: CS1901" value={tag} onChange={(e) => setTag(e.target.value.toUpperCase())} />
              </div>
              <div>
                <Label>Frota</Label>
                <Select value={frota} onValueChange={setFrota}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todas" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todas">Todas</SelectItem>
                    <SelectItem value="KRESS">KRESS</SelectItem>
                    <SelectItem value="CAMINHÕES RODOVIÁRIOS">CAMINHÕES RODOVIÁRIOS</SelectItem>
                    <SelectItem value="CAMINHÕES ARTICULADOS">CAMINHÕES ARTICULADOS</SelectItem>
                    <SelectItem value="ESCAVADEIRAS">ESCAVADEIRAS</SelectItem>
                    <SelectItem value="CARREGADEIRAS">CARREGADEIRAS</SelectItem>
                    <SelectItem value="TRATORES DE ESTEIRA">TRATORES DE ESTEIRA</SelectItem>
                    <SelectItem value="MOTONIVELADORAS">MOTONIVELADORAS</SelectItem>
                    <SelectItem value="CAMINHÕES PIPAS">CAMINHÕES PIPAS</SelectItem>
                    <SelectItem value="CAMINHÕES COMBOIO">CAMINHÕES COMBOIO</SelectItem>
                    <SelectItem value="PERFURATRIZ">PERFURATRIZ</SelectItem>
                    <SelectItem value="CAMINHÃO PRANCHA">CAMINHÃO PRANCHA</SelectItem>
                    <SelectItem value="MINI CARREGADEIRA">MINI CARREGADEIRA</SelectItem>
                    <SelectItem value="CAMINHÕES BAÚ/SIDER">CAMINHÕES BAÚ/SIDER</SelectItem>
                    <SelectItem value="VEICULOS BOMBEIROS">VEICULOS BOMBEIROS</SelectItem>
                    <SelectItem value="RETRO ESCAVADEIRAS">RETRO ESCAVADEIRAS</SelectItem>
                    <SelectItem value="OUTROS">OUTROS</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button onClick={handleAnalyze} disabled={isAnalyzing} className="bg-blue-600 hover:bg-blue-700">
                {isAnalyzing ? (<><Loader2 className="w-4 h-4 mr-2 animate-spin"/> Analisando...</>) : (<>Executar Análise</>)}
              </Button>
              <Button variant="outline" onClick={handleReset} disabled={isAnalyzing} className="gap-2">
                <RefreshCw className="w-4 h-4"/> Reiniciar Análise
              </Button>
              <Badge variant="outline">Registros considerados: {totalConsideredRecords}</Badge>
            </div>
          </CardContent>
        </Card>

        {isAnalyzing && (
          <Card>
            <CardContent className="p-6 text-center text-slate-600">
              <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2"/>
              Executando análise de IA...
            </CardContent>
          </Card>
        )}

        {!isAnalyzing && result && (
          <div className="space-y-6">
            {/* Métricas */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-slate-500">Falhas (total)</p>
                  <p className="text-2xl font-bold">{result?.metrics?.total_failures ?? "-"}</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-slate-500">Equipamentos únicos</p>
                  <p className="text-2xl font-bold">{result?.metrics?.unique_equipments ?? "-"}</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-slate-500">Horas paradas (est.)</p>
                  <p className="text-2xl font-bold">{result?.metrics?.total_downtime_hours ?? "-"}</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-slate-500">Média horas/ocorrência</p>
                  <p className="text-2xl font-bold">{result?.metrics?.avg_downtime_hours ?? "-"}</p>
                </CardContent>
              </Card>
            </div>

            {/* Pareto */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">Pareto de categorias
                  <TooltipProvider>
                    <UiTooltip>
                      <TooltipTrigger asChild>
                        <HelpCircle className="w-4 h-4 text-slate-500" />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="max-w-xs text-sm">Cumulative = soma acumulada do percentual até a categoria. Ex.: 80% indica que as N primeiras categorias somam 80% das ocorrências.</p>
                      </TooltipContent>
                    </UiTooltip>
                  </TooltipProvider>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {Array.isArray(result?.pareto) && result.pareto.length > 0 ? (
                  <>
                    <div className="h-72">
                      <ResponsiveContainer width="100%" height="100%">
                        <ComposedChart data={result.pareto} margin={{ top: 10, right: 20, bottom: 0, left: 0 }}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="category" tick={{ fontSize: 12 }} />
                          <YAxis yAxisId="left" tick={{ fontSize: 12 }} />
                          <YAxis yAxisId="right" orientation="right" tickFormatter={(v)=>`${v}%`} tick={{ fontSize: 12 }} />
                          <Tooltip />
                          <Bar yAxisId="left" dataKey="count" fill="#f59e0b" radius={[4,4,0,0]} />
                          <Line yAxisId="right" type="monotone" dataKey="cumulative" stroke="#2563eb" strokeWidth={2} dot={false} />
                        </ComposedChart>
                      </ResponsiveContainer>
                    </div>
                    <p className="text-xs text-slate-500 -mt-2">"Cumulative" = soma acumulada do percentual até a categoria (ex.: 80% indica que as n primeiras categorias somam 80% das ocorrências).</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {result.pareto.map((p, i) => (
                        <button key={i} onClick={() => { setSelectedCategory(p.category); setShowParetoDialog(true); }} className="text-left border rounded p-3 hover:bg-slate-50 transition">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Badge className="bg-orange-600 text-white">{p?.count ?? 0}</Badge>
                              <span className="font-semibold">{p?.category}</span>
                            </div>
                            <div className="text-sm text-slate-600">{(p?.percentage ?? 0)}% • acum.: {(p?.cumulative ?? 0)}%</div>
                          </div>
                          <p className="text-xs text-slate-500 mt-1">Clique para ver subcategorias</p>
                        </button>
                      ))}
                    </div>
                  </>
                ) : (
                  <p className="text-slate-500">Sem dados suficientes para Pareto.</p>
                )}
              </CardContent>
            </Card>

            {/* Sistemas */}
            <Card>
              <CardHeader>
                <CardTitle>Falhas por sistema</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {Array.isArray(result?.failures_by_system) && result.failures_by_system.length > 0 ? (
                  result.failures_by_system.map((s, i) => (
                    <div key={i} className="border rounded p-3 text-center">
                      <p className="text-xs text-slate-500">{s.system}</p>
                      <p className="text-xl font-bold">{s.count}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-slate-500">Sem dados</p>
                )}
              </CardContent>
            </Card>

            {/* Repetitividade */}
            <Card>
              <CardHeader>
                <CardTitle>Falhas repetitivas</CardTitle>
              </CardHeader>
              <CardContent>
                {Array.isArray(result?.repeated_failures) && result.repeated_failures.length > 0 ? (
                  <div className="space-y-2">
                    {result.repeated_failures.map((r, i) => {
                      const expanded = !!expandedCodes[r.codigo];
                      const equipamento = dataset.find((d) => d.codigo === r.codigo);
                      const ocorrencias = equipamento ? [
                        ...((equipamento.liberacoes || []).map(l => ({ tipo: 'Liberação', data: l.data_liberacao, hora: l.hora_liberacao, detalhes: l.atividades_realizadas }))),
                        ...((equipamento.acoes || []).map(a => ({ tipo: 'Ação', data: a.data_reuniao || a.data_conclusao, detalhes: a.descricao_acao, status: a.status_acao, numero_om: a.numero_om }))),
                      ] : [];
                      return (
                        <div key={i} className="border rounded-lg p-2 bg-white/70 backdrop-blur">
                          <button onClick={() => toggleExpanded(r.codigo)} className="w-full flex items-center justify-between text-left">
                            <div>
                              <p className="font-semibold">{r.codigo}</p>
                              <p className="text-xs text-slate-600">{r.category}</p>
                            </div>
                            <Badge variant="secondary">{r.count}x</Badge>
                          </button>
                          {expanded && (
                            <div className="mt-2 rounded bg-slate-50 p-2 max-h-56 overflow-auto">
                              {ocorrencias.length ? (
                                <ul className="space-y-1 text-sm">
                                  {ocorrencias.map((o, idx) => (
                                    <li key={idx} className="flex items-start">
                                      <span className="mr-2 shrink-0 text-slate-500">•</span>
                                      <div>
                                        <span className="font-medium">{o.tipo}</span> • {o.data || '-'} {o.hora ? `às ${o.hora}` : ''} — {o.detalhes || '-'}
                                        {o.numero_om ? ` (OM ${o.numero_om})` : ''}{o.status ? ` [${o.status}]` : ''}
                                      </div>
                                    </li>
                                  ))}
                                </ul>
                              ) : (
                                <p className="text-slate-500 text-sm">Sem ocorrências detalhadas no período.</p>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-slate-500">Sem padrões de repetição relevantes.</p>
                )}
              </CardContent>
            </Card>

            {/* Tendências */}
            <Card>
              <CardHeader>
                <CardTitle>Tendências</CardTitle>
              </CardHeader>
              <CardContent>
                {Array.isArray(result?.trends) && result.trends.length > 0 ? (
                  <ul className="list-disc pl-5 space-y-1 text-slate-700">
                    {result.trends.map((t, i) => (
                      <li key={i}><strong>{t.category}:</strong> {t.direction}</li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-slate-500">Sem tendências claras.</p>
                )}
              </CardContent>
            </Card>

            {/* Sugestões */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><AlertTriangle className="w-5 h-5 text-red-600"/> Ações Técnicas</CardTitle>
                </CardHeader>
                <CardContent>
                  {Array.isArray(result?.suggestions?.technical) && result.suggestions.technical.length > 0 ? (
                    <div className="space-y-2">
                      {result.suggestions.technical.map((s, i) => (
                        typeof s === 'string' ? (
                          <li key={i} className="list-disc ml-5 text-slate-700">{s}</li>
                        ) : (
                          <div key={i} className="border rounded p-3">
                            <div className="flex items-center justify-between">
                              <p className="font-semibold">{s.title}</p>
                              <div className="flex gap-2">
                                <Badge variant="secondary">{s.priority}</Badge>
                                <Badge variant="outline">Custo: {s.cost_level}</Badge>
                              </div>
                            </div>
                            <p className="text-xs text-slate-600 mt-1">{s.rationale}</p>
                            <p className="text-xs text-slate-600 mt-1">Owner: {s.owner_area} • Impacto: {s.expected_impact_hours ?? '-'}h</p>
                            {Array.isArray(s.steps) && s.steps.length > 0 && (
                              <ul className="list-disc pl-5 text-sm mt-2">
                                {s.steps.map((st, idx) => (<li key={idx}>{st}</li>))}
                              </ul>
                            )}
                          </div>
                        )
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-500">Sem sugestões.</p>
                  )}
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><Lightbulb className="w-5 h-5 text-amber-600"/> Melhoria de Processo</CardTitle>
                </CardHeader>
                <CardContent>
                  {Array.isArray(result?.suggestions?.process) && result.suggestions.process.length > 0 ? (
                    <div className="space-y-2">
                      {result.suggestions.process.map((s, i) => (
                        typeof s === 'string' ? (
                          <li key={i} className="list-disc ml-5 text-slate-700">{s}</li>
                        ) : (
                          <div key={i} className="border rounded p-3">
                            <div className="flex items-center justify-between">
                              <p className="font-semibold">{s.title}</p>
                              <div className="flex gap-2">
                                <Badge variant="secondary">{s.priority}</Badge>
                                <Badge variant="outline">Custo: {s.cost_level}</Badge>
                              </div>
                            </div>
                            <p className="text-xs text-slate-600 mt-1">{s.rationale}</p>
                            <p className="text-xs text-slate-600 mt-1">Owner: {s.owner_area} • Impacto: {s.expected_impact_hours ?? '-'}h</p>
                            {Array.isArray(s.steps) && s.steps.length > 0 && (
                              <ul className="list-disc pl-5 text-sm mt-2">
                                {s.steps.map((st, idx) => (<li key={idx}>{st}</li>))}
                              </ul>
                            )}
                          </div>
                        )
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-500">Sem sugestões.</p>
                  )}
                </CardContent>
              </Card>
            </div>

            {result?.notes && (
              <Card>
                <CardHeader>
                  <CardTitle>Notas</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-700 whitespace-pre-wrap">{result.notes}</p>
                </CardContent>
              </Card>
            )}



            {/* Chat com a IA */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><MessageSquare className="w-5 h-5 text-blue-700"/> Converse com a IA sobre esta análise</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-72 overflow-auto border rounded p-3 bg-white/60">
                  {chatMessages.length === 0 && (
                    <p className="text-sm text-slate-500">Envie uma mensagem para perguntar sobre causas, priorização, materiais críticos, etc.</p>
                  )}
                  {chatMessages.map((m, i) => (
                    <div key={i} className={m.role === 'user' ? 'text-right' : 'text-left'}>
                      <div className={`inline-block rounded px-3 py-2 text-sm ${m.role === 'user' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-800'}`}>
                        {m.content}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-3 flex gap-2 items-start">
                  <Textarea value={chatInput} onChange={(e)=>setChatInput(e.target.value)} placeholder="Digite sua pergunta..." className="min-h-10" />
                  <Button onClick={handleSendChat} disabled={isChatting || !chatInput.trim()} className="gap-2">
                    {isChatting ? (<><Loader2 className="w-4 h-4 animate-spin"/> Enviando...</>) : (<><Send className="w-4 h-4"/> Enviar</>)}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Drilldown Pareto */}
        <Dialog open={showParetoDialog} onOpenChange={setShowParetoDialog}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Detalhamento: {selectedCategory}</DialogTitle>
            </DialogHeader>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={(result?.pareto_breakdown?.[selectedCategory]) || []} margin={{ top: 10, right: 20, bottom: 0, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="subcategory" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Bar dataKey="count" fill="#10b981" radius={[4,4,0,0]} />
                  <Line type="monotone" dataKey="cumulative" stroke="#2563eb" strokeWidth={2} dot={false} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}