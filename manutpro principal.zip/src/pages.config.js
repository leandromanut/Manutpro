/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import AcompanharPreventiva from './pages/AcompanharPreventiva';
import Alocacoes from './pages/Alocacoes';
import AnaliseCorretiva from './pages/AnaliseCorretiva';
import AnaliseFalhaSimples from './pages/AnaliseFalhaSimples';
import AnotacoesTurno from './pages/AnotacoesTurno';
import Assiduidade from './pages/Assiduidade';
import Colaboradores from './pages/Colaboradores';
import Equipamentos from './pages/Equipamentos';
import Habilitacoes from './pages/Habilitacoes';
import HistoricoEquipamento from './pages/HistoricoEquipamento';
import Home from './pages/Home';
import ImportarManutencoes from './pages/ImportarManutencoes';
import IniciarTurno from './pages/IniciarTurno';
import MapaOficina from './pages/MapaOficina';
import QuadroVisaoGeral from './pages/QuadroVisaoGeral';
import RecuperarDados from './pages/RecuperarDados';
import Relatorio from './pages/Relatorio';
import RelatorioAssiduidade from './pages/RelatorioAssiduidade';
import RelatorioHabilitacoes from './pages/RelatorioHabilitacoes';
import RelatorioPreventiva from './pages/RelatorioPreventiva';
import RelatorioPreventivaConcluidas from './pages/RelatorioPreventivaConcluidas';
import RelatorioTurno from './pages/RelatorioTurno';
import RelatorioVisaoGeral from './pages/RelatorioVisaoGeral';
import ReuniaoDiaria from './pages/ReuniaoDiaria';
import TratativasOM from './pages/TratativasOM';
import UploadProgramacao from './pages/UploadProgramacao';
import VisaoGeral from './pages/VisaoGeral';
import __Layout from './Layout.jsx';


export const PAGES = {
    "AcompanharPreventiva": AcompanharPreventiva,
    "Alocacoes": Alocacoes,
    "AnaliseCorretiva": AnaliseCorretiva,
    "AnaliseFalhaSimples": AnaliseFalhaSimples,
    "AnotacoesTurno": AnotacoesTurno,
    "Assiduidade": Assiduidade,
    "Colaboradores": Colaboradores,
    "Equipamentos": Equipamentos,
    "Habilitacoes": Habilitacoes,
    "HistoricoEquipamento": HistoricoEquipamento,
    "Home": Home,
    "ImportarManutencoes": ImportarManutencoes,
    "IniciarTurno": IniciarTurno,
    "MapaOficina": MapaOficina,
    "QuadroVisaoGeral": QuadroVisaoGeral,
    "RecuperarDados": RecuperarDados,
    "Relatorio": Relatorio,
    "RelatorioAssiduidade": RelatorioAssiduidade,
    "RelatorioHabilitacoes": RelatorioHabilitacoes,
    "RelatorioPreventiva": RelatorioPreventiva,
    "RelatorioPreventivaConcluidas": RelatorioPreventivaConcluidas,
    "RelatorioTurno": RelatorioTurno,
    "RelatorioVisaoGeral": RelatorioVisaoGeral,
    "ReuniaoDiaria": ReuniaoDiaria,
    "TratativasOM": TratativasOM,
    "UploadProgramacao": UploadProgramacao,
    "VisaoGeral": VisaoGeral,
}

export const pagesConfig = {
    mainPage: "IniciarTurno",
    Pages: PAGES,
    Layout: __Layout,
};