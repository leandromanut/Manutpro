import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

function nowInSaoPaulo() {
  const parts = new Intl.DateTimeFormat('pt-BR', {
    timeZone: 'America/Sao_Paulo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(new Date());

  const get = (type) => parts.find((p) => p.type === type)?.value?.padStart(2, '0');
  const day = get('day');
  const month = get('month');
  const year = parts.find((p) => p.type === 'year')?.value;
  const hour = get('hour');
  const minute = get('minute');

  const dateISO = `${year}-${month}-${day}`; // YYYY-MM-DD
  const timeHM = `${hour}:${minute}`;       // HH:MM
  return { dateISO, timeHM };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();

    // Expecting automation payload shape: { event: { entity_id, ... }, data, payload_too_large }
    const event = payload?.event || {};
    const entityId = event.entity_id;

    if (!entityId) {
      return Response.json({ error: 'Missing entity_id in event' }, { status: 400 });
    }

    let record = payload?.data;

    if (!record || payload?.payload_too_large) {
      // Fallback: fetch the record
      const list = await base44.asServiceRole.entities.LiberacaoEquipamento.filter({ id: entityId });
      record = Array.isArray(list) ? list[0] : null;
    }

    if (!record) {
      return Response.json({ error: 'Record not found' }, { status: 404 });
    }

    const updates = {};
    const { dateISO, timeHM } = nowInSaoPaulo();

    if (!record.hora_liberacao) {
      updates.hora_liberacao = timeHM;
    }
    if (!record.data_liberacao) {
      updates.data_liberacao = dateISO;
    }

    if (Object.keys(updates).length > 0) {
      await base44.asServiceRole.entities.LiberacaoEquipamento.update(entityId, updates);
    }

    return Response.json({ ok: true, updated: Object.keys(updates) });
  } catch (error) {
    return Response.json({ error: error?.message || 'Unhandled error' }, { status: 500 });
  }
});