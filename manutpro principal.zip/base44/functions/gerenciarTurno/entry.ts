import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Não autorizado' }, { status: 401 });
    }

    const body = await req.json();
    console.log('📥 Requisição recebida:', JSON.stringify(body));
    
    const { acao, dadosTurno } = body;

    if (acao === 'iniciar') {
      if (!dadosTurno || !dadosTurno.letraTurno || !dadosTurno.supervisor || !dadosTurno.data) {
        return Response.json({ 
          error: 'Dados incompletos para iniciar turno',
          detalhes: { dadosTurno }
        }, { status: 400 });
      }
      return await iniciarTurno(base44, dadosTurno);
    } else if (acao === 'encerrar') {
      return await encerrarTurno(base44);
    } else {
      return Response.json({ error: 'Ação inválida' }, { status: 400 });
    }
  } catch (error) {
    console.error('❌ Erro na função gerenciarTurno:', error);
    return Response.json({ 
      error: error.message || 'Erro desconhecido',
      stack: error.stack
    }, { status: 500 });
  }
});

// Função auxiliar para buscar TODOS os registros de uma entidade usando filter
async function buscarTodosRegistros(base44, entityName) {
  console.log(`🔍 Buscando todos os registros de ${entityName} com filter()...`);
  
  try {
    // Usar filter com query vazia - mais confiável que list
    const registros = await base44.asServiceRole.entities[entityName].filter({}, '-created_date', 5000);
    console.log(`✅ ${entityName} - Total encontrado: ${registros.length} registros`);
    
    return registros;
  } catch (error) {
    console.error(`❌ Erro ao buscar ${entityName}:`, error.message);
    throw error;
  }
}

// Função para atualizar colaboradores em lotes pequenos com retry agressivo
async function atualizarColaboradoresEmLotes(base44, colaboradores, updateData, tipoAtualizacao) {
  const batchSize = 3; // Lotes MUITO pequenos para maior confiabilidade
  let sucessos = 0;
  let erros = 0;
  const errosDetalhados = [];
  
  console.log(`🔄 Iniciando atualização de ${colaboradores.length} colaboradores (${tipoAtualizacao})...`);
  
  for (let i = 0; i < colaboradores.length; i += batchSize) {
    const batch = colaboradores.slice(i, i + batchSize);
    console.log(`📦 Processando lote ${Math.floor(i/batchSize) + 1}/${Math.ceil(colaboradores.length/batchSize)} (${batch.length} colaboradores)...`);
    
    const promises = batch.map(async (colab) => {
      const dataToUpdate = typeof updateData === 'function' ? updateData(colab) : updateData;
      
      // Retry agressivo: até 5 tentativas com delay crescente
      for (let tentativa = 1; tentativa <= 5; tentativa++) {
        try {
          await base44.asServiceRole.entities.Colaborador.update(colab.id, dataToUpdate);
          console.log(`✅ [${tentativa}ª tent.] ${colab.nome} atualizado`);
          return { sucesso: true, nome: colab.nome, id: colab.id };
        } catch (err) {
          console.error(`❌ [${tentativa}ª tent.] Erro ao atualizar ${colab.nome}:`, err.message);
          
          if (tentativa === 5) {
            errosDetalhados.push({ nome: colab.nome, id: colab.id, erro: err.message });
            return { sucesso: false, nome: colab.nome, id: colab.id, erro: err.message };
          }
          
          // Delay crescente: 200ms, 400ms, 800ms, 1600ms
          await new Promise(resolve => setTimeout(resolve, 200 * Math.pow(2, tentativa - 1)));
        }
      }
    });
    
    const resultados = await Promise.all(promises);
    sucessos += resultados.filter(r => r.sucesso).length;
    erros += resultados.filter(r => !r.sucesso).length;
    
    console.log(`📊 Progresso: ${sucessos}/${colaboradores.length} sucessos, ${erros} erros`);
    
    // Delay entre lotes
    if (i + batchSize < colaboradores.length) {
      await new Promise(resolve => setTimeout(resolve, 200));
    }
  }
  
  console.log(`\n✅ RESUMO (${tipoAtualizacao}):`);
  console.log(`   ✓ Sucessos: ${sucessos}/${colaboradores.length}`);
  console.log(`   ✗ Erros: ${erros}`);
  
  if (errosDetalhados.length > 0) {
    console.error(`\n❌ ERROS DETALHADOS (${tipoAtualizacao}):`);
    errosDetalhados.forEach(erro => {
      console.error(`   - ${erro.nome} (ID: ${erro.id}): ${erro.erro}`);
    });
  }
  
  return { sucessos, erros, errosDetalhados };
}

async function iniciarTurno(base44, dadosTurno) {
  const { letraTurno, supervisor, tecnicos, data, horarioInicio, horarioFim } = dadosTurno;

  try {
    console.log('🚀 ========== INICIANDO TURNO ==========');
    console.log(`📅 Data: ${data}, Turno: ${letraTurno}, Supervisor: ${supervisor}`);

    // PASSO 1: Desativar turno anterior
    console.log('\n📋 PASSO 1: Desativando turno anterior...');
    const turnos = await base44.asServiceRole.entities.Turno.list();
    const turnoAtivo = turnos.find(t => t.ativo);
    
    if (turnoAtivo) {
      console.log(`🔄 Desativando turno ${turnoAtivo.letra} (ID: ${turnoAtivo.id})...`);
      await base44.asServiceRole.entities.Turno.update(turnoAtivo.id, { ativo: false });
      console.log('✅ Turno anterior desativado com sucesso');
    } else {
      console.log('ℹ️ Nenhum turno ativo encontrado');
    }

    // PASSO 2: Criar novo turno
    console.log('\n🆕 PASSO 2: Criando novo turno...');
    const novoTurno = await base44.asServiceRole.entities.Turno.create({
      letra: letraTurno,
      supervisor: supervisor,
      tecnicos_lideres: tecnicos || "",
      horario_inicio: horarioInicio,
      horario_fim: horarioFim,
      data: data,
      ativo: true
    });
    console.log(`✅ Novo turno criado com sucesso (ID: ${novoTurno.id})`);

    // PASSO 3: Buscar TODOS os colaboradores
    console.log('\n👥 PASSO 3: Buscando TODOS os colaboradores...');
    const todosColaboradores = await buscarTodosRegistros(base44, 'Colaborador');
    console.log(`✅ Total de colaboradores encontrados: ${todosColaboradores.length}`);
    
    // Log dos últimos colaboradores para debug
    if (todosColaboradores.length > 0) {
      const ultimos5 = todosColaboradores.slice(-5);
      console.log('📋 Últimos 5 colaboradores:');
      ultimos5.forEach((c, idx) => {
        console.log(`   ${idx + 1}. ${c.nome} (${c.empresa}) - Turno: ${c.turno_padrao}`);
      });
    }

    // PASSO 4: Determinar quem deve estar presente
    console.log('\n🎯 PASSO 4: Determinando colaboradores presentes...');
    const dataObj = new Date(data + 'T00:00:00');
    const diaDaSemana = dataObj.getDay();
    const isDiaDeSemana = diaDaSemana >= 1 && diaDaSemana <= 5;
    console.log(`📅 Dia da semana: ${diaDaSemana} (0=Dom, 6=Sáb), É dia de semana: ${isDiaDeSemana}`);

    const colaboradoresPresentes = [];
    const colaboradoresAusentes = [];

    todosColaboradores.forEach(c => {
      let deveEstarPresente = false;
      
      // Regra 1: Turno padrão igual ao turno atual
      if (c.turno_padrao === letraTurno) {
        deveEstarPresente = true;
      }
      // Regra 2: ADM trabalha em dias de semana nos turnos A e C
      else if (isDiaDeSemana && (letraTurno === 'A' || letraTurno === 'C') && c.turno_padrao === 'ADM') {
        deveEstarPresente = true;
      }
      
      if (deveEstarPresente) {
        colaboradoresPresentes.push(c);
      } else {
        colaboradoresAusentes.push(c);
      }
    });
    
    console.log(`✅ Colaboradores que devem estar PRESENTES: ${colaboradoresPresentes.length}`);
    console.log(`✅ Colaboradores que devem estar AUSENTES: ${colaboradoresAusentes.length}`);
    console.log(`📊 Total: ${colaboradoresPresentes.length + colaboradoresAusentes.length} = ${todosColaboradores.length}`);

    // PASSO 5: Atualizar colaboradores que precisam mudar de status
    console.log('\n🔄 PASSO 5: Filtrando e atualizando apenas colaboradores que precisam mudar...');

    // 5a. Filtrar apenas presentes que estão marcados como ausentes
    const presentesParaAtualizar = colaboradoresPresentes.filter(c => c.presente !== true);
    console.log(`📋 Presentes para atualizar: ${presentesParaAtualizar.length}/${colaboradoresPresentes.length}`);

    // 5b. Filtrar apenas ausentes que estão marcados como presentes
    const ausentesParaAtualizar = colaboradoresAusentes.filter(c => c.presente === true);
    console.log(`📋 Ausentes para atualizar: ${ausentesParaAtualizar.length}/${colaboradoresAusentes.length}`);

    let resultadoPresentes = { sucessos: 0, erros: 0, errosDetalhados: [] };
    let resultadoAusentes = { sucessos: 0, erros: 0, errosDetalhados: [] };

    // 5c. Marcar presentes
    if (presentesParaAtualizar.length > 0) {
      console.log(`\n👍 5c. Marcando ${presentesParaAtualizar.length} colaboradores como PRESENTES...`);
      resultadoPresentes = await atualizarColaboradoresEmLotes(
        base44,
        presentesParaAtualizar,
        (c) => {
          const updateData = {
            presente: true,
            disponivel: true,
            motivo_ausencia: null,
            motivo_ocupacao: null
          };

          // Marcar funções especiais como ocupadas
          const funcaoLower = (c.funcao || '').toLowerCase();
          if (funcaoLower.includes('lavador')) {
            updateData.disponivel = false;
            updateData.motivo_ocupacao = 'lavador';
          } else if (funcaoLower.includes('soldador') || funcaoLower.includes('solda')) {
            updateData.disponivel = false;
            updateData.motivo_ocupacao = 'solda_box';
          } else if (funcaoLower.includes('comboio')) {
            updateData.disponivel = false;
            updateData.motivo_ocupacao = 'comboio';
          }

          return updateData;
        },
        'MARCAR PRESENTES'
      );
    } else {
      console.log(`ℹ️ Nenhum colaborador presente precisa ser atualizado`);
    }

    // 5d. Marcar ausentes
    if (ausentesParaAtualizar.length > 0) {
      console.log(`\n👎 5d. Marcando ${ausentesParaAtualizar.length} colaboradores como AUSENTES...`);
      resultadoAusentes = await atualizarColaboradoresEmLotes(
        base44,
        ausentesParaAtualizar,
        {
          presente: false,
          disponivel: true,
          motivo_ausencia: null,
          motivo_ocupacao: null
        },
        'MARCAR AUSENTES'
      );
    } else {
      console.log(`ℹ️ Nenhum colaborador ausente precisa ser atualizado`);
    }

    const sucessosPresentes = resultadoPresentes.sucessos;
    const errosPresentes = resultadoPresentes.erros;
    const sucessosAusentes = resultadoAusentes.sucessos;
    const errosAusentes = resultadoAusentes.erros;

    // RESUMO FINAL
    const totalSucessos = sucessosPresentes + sucessosAusentes;
    const totalErros = errosPresentes + errosAusentes;
    
    console.log('\n🎉 ========== RESUMO FINAL ==========');
    console.log(`✅ Turno criado: ${letraTurno} (${supervisor})`);
    console.log(`✅ Total processado: ${totalSucessos}/${todosColaboradores.length} colaboradores`);
    console.log(`   - Presentes: ${sucessosPresentes}/${colaboradoresPresentes.length}`);
    console.log(`   - Ausentes: ${sucessosAusentes}/${colaboradoresAusentes.length}`);
    console.log(`❌ Total de erros: ${totalErros}`);
    console.log('=====================================\n');

    return Response.json({
      success: true,
      message: 'Turno iniciado com sucesso',
      turno: novoTurno,
      estatisticas: {
        totalColaboradores: todosColaboradores.length,
        colaboradoresPresentes: colaboradoresPresentes.length,
        colaboradoresAusentes: colaboradoresAusentes.length,
        sucessosPresentes,
        sucessosAusentes,
        errosPresentes,
        errosAusentes,
        totalSucessos,
        totalErros
      }
    });

  } catch (error) {
    console.error('❌ ========== ERRO AO INICIAR TURNO ==========');
    console.error(error);
    console.error('=============================================');
    throw error;
  }
}

async function encerrarTurno(base44) {
  try {
    console.log('🛑 ========== ENCERRANDO TURNO ==========');

    // PASSO 1: Buscar TODOS os dados
    console.log('\n📋 PASSO 1: Buscando todos os dados...');
    const [turnos, alocacoes, todosColaboradores] = await Promise.all([
      base44.asServiceRole.entities.Turno.list('-created_date', 1000),
      base44.asServiceRole.entities.Alocacao.list('-created_date', 5000),
      buscarTodosRegistros(base44, 'Colaborador')
    ]);
    
    console.log(`✅ Dados carregados:`);
    console.log(`   - Turnos: ${turnos.length}`);
    console.log(`   - Alocações: ${alocacoes.length}`);
    console.log(`   - Colaboradores: ${todosColaboradores.length}`);
    
    if (todosColaboradores.length > 0) {
      const ultimos5 = todosColaboradores.slice(-5);
      console.log('📋 Últimos 5 colaboradores:');
      ultimos5.forEach((c, idx) => {
        console.log(`   ${idx + 1}. ${c.nome} (${c.empresa}) - ID: ${c.id}`);
      });
    }

    // PASSO 2: Desativar turno
    console.log('\n🔄 PASSO 2: Desativando turno ativo...');
    const turnoAtivo = turnos.find(t => t.ativo);
    if (turnoAtivo) {
      console.log(`   Desativando turno ${turnoAtivo.letra} (ID: ${turnoAtivo.id})...`);
      await base44.asServiceRole.entities.Turno.update(turnoAtivo.id, { ativo: false });
      console.log('✅ Turno desativado com sucesso');
    } else {
      console.log('ℹ️ Nenhum turno ativo encontrado');
    }

    // PASSO 3: Remover TODAS as alocações
    console.log(`\n🗑️ PASSO 3: Removendo ${alocacoes.length} alocações...`);
    let alocacoesRemovidas = 0;
    let errosAlocacoes = 0;
    const batchSize = 5;
    
    for (let i = 0; i < alocacoes.length; i += batchSize) {
      const batch = alocacoes.slice(i, i + batchSize);
      
      const promises = batch.map(async (a) => {
        for (let tentativa = 1; tentativa <= 3; tentativa++) {
          try {
            await base44.asServiceRole.entities.Alocacao.delete(a.id);
            return { sucesso: true };
          } catch (err) {
            if (tentativa === 3) {
              console.error(`❌ Falha ao remover alocação ${a.id}:`, err.message);
              return { sucesso: false };
            }
            await new Promise(resolve => setTimeout(resolve, 150));
          }
        }
      });
      
      const resultados = await Promise.all(promises);
      alocacoesRemovidas += resultados.filter(r => r.sucesso).length;
      errosAlocacoes += resultados.filter(r => !r.sucesso).length;
      
      if ((i + batchSize) % 20 === 0 || i + batchSize >= alocacoes.length) {
        console.log(`   📊 Progresso: ${alocacoesRemovidas}/${alocacoes.length} removidas (${errosAlocacoes} erros)`);
      }
      
      if (i + batchSize < alocacoes.length) {
        await new Promise(resolve => setTimeout(resolve, 150));
      }
    }
    console.log(`✅ ${alocacoesRemovidas} alocações removidas, ${errosAlocacoes} erros`);

    // PASSO 4: Marcar apenas colaboradores PRESENTES como ausentes (otimização)
    const presentesParaMarcarAusentes = todosColaboradores.filter(c => c.presente === true);
    console.log(`\n👥 PASSO 4: Marcando ${presentesParaMarcarAusentes.length}/${todosColaboradores.length} colaboradores como AUSENTES...`);
    console.log(`ℹ️ (${todosColaboradores.length - presentesParaMarcarAusentes.length} já estão ausentes, pulando)`);

    let resultado = { sucessos: 0, erros: 0, errosDetalhados: [] };

    if (presentesParaMarcarAusentes.length > 0) {
      resultado = await atualizarColaboradoresEmLotes(
        base44,
        presentesParaMarcarAusentes,
        {
          presente: false,
          disponivel: true,
          motivo_ausencia: null,
          motivo_ocupacao: null
        },
        'ENCERRAR TURNO - MARCAR AUSENTES'
      );
    }

    const sucessos = resultado.sucessos;
    const erros = resultado.erros;

    // RESUMO FINAL
    console.log('\n🎉 ========== RESUMO FINAL ==========');
    console.log(`✅ Turno desativado: ${turnoAtivo ? turnoAtivo.letra : 'Nenhum'}`);
    console.log(`✅ Alocações removidas: ${alocacoesRemovidas}/${alocacoes.length}`);
    console.log(`✅ Colaboradores atualizados: ${sucessos}/${todosColaboradores.length}`);
    console.log(`❌ Total de erros: ${erros + errosAlocacoes}`);
    console.log('=====================================\n');

    return Response.json({
      success: true,
      message: 'Turno encerrado com sucesso',
      alocacoesRemovidas,
      colaboradoresMarcados: sucessos,
      erros: erros + errosAlocacoes,
      estatisticas: {
        turnoDesativado: turnoAtivo ? turnoAtivo.letra : null,
        totalAlocacoes: alocacoes.length,
        alocacoesRemovidas,
        errosAlocacoes,
        totalColaboradores: todosColaboradores.length,
        colaboradoresMarcados: sucessos,
        errosColaboradores: erros,
        totalErros: erros + errosAlocacoes
      }
    });

  } catch (error) {
    console.error('❌ ========== ERRO AO ENCERRAR TURNO ==========');
    console.error(error);
    console.error('==============================================');
    throw error;
  }
}