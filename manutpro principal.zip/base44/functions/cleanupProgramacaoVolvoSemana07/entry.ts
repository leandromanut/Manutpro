import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Autenticação obrigatória e admin-only
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }
    if (user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    // Parâmetros alvo (fixos para a correção solicitada)
    const ano = 2026;
    const frota = 'VOLVO';
    const semanaNumero = 7; // aceita 7 ou 07 no campo numero_semana

    // Buscar programações da frota/ano e filtrar pela semana 07 (independente de zero à esquerda)
    const progs = await base44.asServiceRole.entities.ProgramacaoSemanal.filter({ ano, frota });
    const alvo = (progs || []).filter((p) => {
      const m = (p.numero_semana || '').match(/\d+/);
      const n = m ? parseInt(m[0], 10) : null;
      return n === semanaNumero;
    });

    if (!alvo.length) {
      return Response.json({ updated: 0, message: 'Nenhuma programação VOLVO encontrada para Semana 07/2026' });
    }

    const updatedIds = [];
    for (const p of alvo) {
      await base44.asServiceRole.entities.ProgramacaoSemanal.update(p.id, {
        arquivo_volvo_url: '',
        equipamentos: [],
      });
      updatedIds.push(p.id);
    }

    return Response.json({
      updated: updatedIds.length,
      ids: updatedIds,
      message: 'Programação VOLVO da Semana 07/2026 limpa com sucesso (arquivo removido e equipamentos zerados).'
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});